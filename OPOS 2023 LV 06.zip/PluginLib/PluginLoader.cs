﻿using System.Reflection;

namespace PluginLib
{
    /// <summary>
    /// Example usage:
    /// <code>
    ///     Assembly assembly = PluginLoader.LoadPlugin(dllFilePath);
    ///     IEnumerable<Type> targetTypes = PluginLoader.GetSubtypes<IExampleInterface>(assembly);
    ///     var filteredTypes = jobTypes.Where(type => type.IsPublic && !type.IsInterface && !type.IsAbstract));
    /// </code>
    /// </summary>
    public class PluginLoader
    {
        /// <summary>
        /// Load plugin DLL from <paramref name="path"/>.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static Assembly LoadPlugin(string path)
        {
            path = path.Replace('\\', Path.DirectorySeparatorChar);
            PluginLoadContext loadContext = new(path);
            return loadContext.LoadFromAssemblyName(new AssemblyName(Path.GetFileNameWithoutExtension(path)));
        }

        /// <summary>
        /// Get subtypes of type T within the assembly. Every type is considered a subtype of itself.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="assembly"></param>
        /// <returns></returns>
        public static IEnumerable<Type> GetSubtypes<T>(Assembly assembly)
        {
            return assembly.GetTypes().Where(type => typeof(T).IsAssignableFrom(type));
        }
    }
}
