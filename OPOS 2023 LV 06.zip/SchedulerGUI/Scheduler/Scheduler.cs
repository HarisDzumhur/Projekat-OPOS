﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerGUI
{
    internal class Scheduler
    {
        public ObservableCollection<Job> Jobs { get; } = new();
        public Scheduler()
        {

        }
    }
}
