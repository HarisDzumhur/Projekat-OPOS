﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace SchedulerGUI
{
    public enum State
    {
        NotStarted,
        Running,
        Finished
    }
    public class Job : INotifyPropertyChanged
    {
        private State _state = State.NotStarted;
        public State State
        {
            get => _state;
            private set
            {
                _state = value;
                NotifyPropertyChanged();
                NotifyPropertyChanged(nameof(IsStartable));
            }
        }
        private readonly object stateLock = new();

        public string Name { get; set; } = "Job";
        private double progress;
        public double Progress
        {
            get
            {
                return progress;
            }

            private set
            {
                progress = value;
                NotifyPropertyChanged();
            }
        }

        public void RequestStart()
        {
            // TODO Cannot start a job that is already running.

            lock (stateLock)
            {
                State = State.Running;
            }

            Task.Run(async () =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Progress = i / 100.0;
                    await Task.Delay(20);
                }

                lock (stateLock)
                {
                    State = State.Finished;
                }
            });
        }

        [JsonIgnore] // Ovo svojstvo ne treba da se serijalizuje pri JSON serijalizaciji.
        public bool IsStartable
        {
            get
            {
                lock (stateLock)
                {
                    return State == State.NotStarted;
                }
            }
        }

        // TODO Implement
        [JsonIgnore]
        public bool IsPauseableOrResumable
        {
            get => false;
        }

        /* Vidjeti:
         * https://learn.microsoft.com/en-us/dotnet/api/system.componentmodel.inotifypropertychanged.propertychanged
         * https://learn.microsoft.com/en-us/dotnet/desktop/wpf/data/how-to-implement-property-change-notification
         */
        public event PropertyChangedEventHandler? PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
