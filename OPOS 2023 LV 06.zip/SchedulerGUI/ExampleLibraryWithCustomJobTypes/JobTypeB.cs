﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerGUI
{
    public class JobTypeB
    {
        public string JobName { get; set; } = "JobTypeA Job";
        public string SomeOtherData { get; set; } = "Example data...";
        public int ExampleInteger { get; set; } = 7;
    }
}
