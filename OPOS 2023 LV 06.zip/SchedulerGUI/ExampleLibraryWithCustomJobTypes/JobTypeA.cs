﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerGUI
{
    public class JobTypeA
    {
        public string Name { get; set; } = "JobTypeA Job";
    }
}
