﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulerGUI
{
    /// <summary>
    /// Interaction logic for CreateJobWindow.xaml
    /// </summary>
    public partial class CreateJobWindow : Window
    {
        public CreateJobWindow()
        {
            InitializeComponent();
            IEnumerable<Type> jobTypes = new List<Type> { typeof(JobTypeA), typeof(JobTypeB) } ; // TODO Ubrizgati tipove posla
            Job job = new Job();
            DataContext = job; // Kontekst za vezivanja -- podrazumijevani element za koji se vezuje, ako nije specificiran naziv elementa
            JobTypeListBox.ItemsSource = jobTypes;
            JobTypeListBox.SelectedIndex = 0; // Podrazumijevano odabran prvi
        }

        private void JobTypeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // TODO Obraditi događaj promjene izbora posla
            
            Type? selectedUserJobType = (Type?)e.AddedItems[0]; // Podrazumijevano odabran prvi mogući tip posla
            Debug.Assert(selectedUserJobType != null);
            object? userJob = (object?)Activator.CreateInstance(selectedUserJobType); // TODO interfejs za poslove umjesto Object
            Debug.Assert(userJob != null);
            UserJobJsonTextBox.Text = JsonSerializer.Serialize(userJob, userJob.GetType(), jsonSerializerOptions);
            // TODO Pri kreiranju posla deserijalizovati tekst (JsonSerializer.Deserialize)
            // Odabrani posao će na kraju biti (Type)JobTypeListBox.SelectedItem;
        }

        private static readonly JsonSerializerOptions jsonSerializerOptions = new() { WriteIndented = true };
    }
}
