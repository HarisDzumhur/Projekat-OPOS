using NUnit.Framework;
using PolymorphicSerialization;
using System.Collections.Generic;
using System.Text.Json;

namespace PolymorphicSerializationTests
{
    interface I
    {

    }

    class A : I
    {
        public int X { get; set; } = 0;
    }

    class B : I
    {
        public string Y { get; set; } = "";
    }

    class P
    {
        public List<I> ListOfIs { get; set; } = new();
    }

    [TestFixture]
    public class PolymorphicJsonConverterTests
    {
        JsonSerializerOptions jsonSerializerOptions = new()
        {
            Converters =
                {
                    new PolymorphicJsonConverter<I>()
                },
        };

        [Test]
        public void TestPolymorphicJsonConverterSimple()
        {
            I a = new A() { X = 42 };
            I b = new B() { Y = "Hello world" };
            string aStr = JsonSerializer.Serialize(a, jsonSerializerOptions);
            string bStr = JsonSerializer.Serialize(b, jsonSerializerOptions);
            string expectedJsonA = """{"Type":"PolymorphicSerializationTests.A, PolymorphicSerializationTests, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null","Data":{"X":42}}""";
            string expectedJsonB = """{"Type":"PolymorphicSerializationTests.B, PolymorphicSerializationTests, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null","Data":{"Y":"Hello world"}}""";
            Assert.That(aStr, Is.EqualTo(expectedJsonA));
            Assert.That(bStr, Is.EqualTo(expectedJsonB));
            I? aD = JsonSerializer.Deserialize<I>(aStr, jsonSerializerOptions);
            I? bD = JsonSerializer.Deserialize<I>(bStr, jsonSerializerOptions);
            Assert.IsNotNull(aD);
            Assert.IsNotNull(bD);
            Assert.True(aD.GetType() == typeof(A));
            Assert.True(bD.GetType() == typeof(B));
            Assert.That(((A)aD).X, Is.EqualTo(42));
            Assert.That(((B)bD).Y, Is.EqualTo("Hello world"));
        }

        [Test]
        public void TestPolymorphicJsonConverterWithArray()
        {
            P p = new() { ListOfIs = new() { new A() { X = 42 }, new B() { Y = "Hello world" } } };
            string pStr = JsonSerializer.Serialize(p, jsonSerializerOptions);
            string expectedJson = """{"ListOfIs":[{"Type":"PolymorphicSerializationTests.A, PolymorphicSerializationTests, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null","Data":{"X":42}},{"Type":"PolymorphicSerializationTests.B, PolymorphicSerializationTests, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null","Data":{"Y":"Hello world"}}]}""";
            Assert.That(pStr, Is.EqualTo(expectedJson));
            P? pD = JsonSerializer.Deserialize<P>(pStr, jsonSerializerOptions);
            Assert.That(pD, Is.Not.Null);
            Assert.That(pD.ListOfIs[0].GetType() == typeof(A));
            Assert.That(pD.ListOfIs[1].GetType() == typeof(B));
            Assert.That(((A)pD.ListOfIs[0]).X, Is.EqualTo(42));
            Assert.That(((B)pD.ListOfIs[1]).Y, Is.EqualTo("Hello world"));
        }
    }
}