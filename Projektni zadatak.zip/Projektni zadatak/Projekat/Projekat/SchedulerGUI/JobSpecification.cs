﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat
{
    public class JobSpecification
    {
        public IJob Job { get; }
        public int Priority { get; set; } = 0;

        public string Name { get; set; } = "Job";
        /*private double progress;
        public double Progress //ovo ce nam trebati vjerovatno za autosave mehanizam
        {
            get
            {
                return progress;
            }

            private set
            {
                progress = value;
            }
        }*/

        public JobSpecification(IJob job, int priority = 0, string name = "Job")
        {
            Job = job;
            Priority = priority;
            Name = name;
        }
    }
}

