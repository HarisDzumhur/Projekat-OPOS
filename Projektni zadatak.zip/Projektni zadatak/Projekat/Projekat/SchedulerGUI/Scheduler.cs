﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat
{
    internal class Scheduler
    {
        private int _maxConJobs;
        public int MaxConJobs {
            get { return _maxConJobs; }
            set { _maxConJobs = value; }
        }

        public ObservableCollection<Job> Jobs { get; } = new ObservableCollection<Job>();
        private int currentlyRunningJobCount = 0;
        private readonly object _lock = new object();
        public Scheduler(int maxConJobs = 0)
        {
            MaxConJobs = maxConJobs;
        }

        public Job Schedule(JobSpecification jobSpecification)
        {
            JobExecutionContext jobExecutionContext = new JobExecutionContext(jobSpecification.Job, jobSpecification.Priority);
            jobExecutionContext.OnFinished = HandleJobFinished;
            jobExecutionContext.OnPaused = HandleJobPaused;
            jobExecutionContext.OnStopped = HandleJobStopped;
            jobExecutionContext.OnResumeRequested = HandleJobResumeRequest;


            Schedule(jobExecutionContext);

            return new Job(jobExecutionContext);
        }

        private readonly PriorityQueue<JobExecutionContext, int> jobQueue = new PriorityQueue();
        private void Schedule(JobExecutionContext jobExecutionContext)
        {
            lock (_lock)
            {
                if (currentlyRunningJobCount < _maxConJobs)
                {
                    currentlyRunningJobCount++;
                    jobExecutionContext.Start();
                }
                else
                {
                    jobQueue.Enqueue(jobExecutionContext, jobExecutionContext.Priority);
                }
            }
        }

        private void FreeJobSlot()
        {
            lock (_lock)
            {
                currentlyRunningJobCount--;
                if (jobQueue.TryDequeue(out JobExecutionContext jobExecutionContext, out int priority)) //?
                {
                    Schedule(jobExecutionContext);
                }
            }
        }

        private void HandleJobFinished()
            => FreeJobSlot();

        private void HandleJobPaused()
            => FreeJobSlot();

        private void HandleJobStopped()
            => FreeJobSlot();

        private void HandleJobResumeRequest(JobExecutionContext jobExecutionContext)
            => Schedule(jobExecutionContext);
    }
}
