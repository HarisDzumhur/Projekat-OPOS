﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Projekat
{
    public class JobTypeA : IJob
    {
        public string Name { get; set; } = "JobTypeA";
        public JobTypeA(string name)
        {
            Name = name;
        }
        public void Run(IJobApi api)
        {
            Console.WriteLine($"Job {Name} started. ");

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"{Name}: {i}");
                Thread.Sleep(new Random().Next(500, 1500));
                api.CheckForInterrupts();
            }
            Console.WriteLine($"Job {Name} ended. ");
        }
    }
}
