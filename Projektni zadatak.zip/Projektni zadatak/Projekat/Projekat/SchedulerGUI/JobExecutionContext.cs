﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Projekat
{
    public enum JobState
    {
        NotStarted,
        Running,
        Finished,
        RunningWithPauseRequest,
        RunningWithStopRequest,
        Paused,
        WaitingToResume,
        Stopped
    }
    public class JobExecutionContext : IJobApi
    {
        
        private JobState state;
        private readonly IJob job;
        private readonly object _lock = new object();
        public int Priority { get; set; } = 1;
        public JobState State { get { return state; } set { state = value; } }

        internal Action OnPaused { get; set; } = () => { };
        internal Action OnStopped { get; set; } = () => { };
        internal Action OnFinished { get; set; } = () => { };
        internal Action<JobExecutionContext> OnResumeRequested { get; set; } = (JobExecutionContext jobExecutionContext) => { };

        public JobExecutionContext(IJob job, int priority)
        {
            this.job = job;
            this.Priority = priority;
        }


        internal void Start()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        state = JobState.Running;
                        new Thread(() =>
                        {
                            try
                            {
                                job.Run(this);
                                Finish();
                            }
                            catch (JobStoppedException)
                            {
                                state = JobState.Stopped;
                            }
                        }).Start();
                        break;
                    case JobState.Running:
                        throw new InvalidOperationException("Job cannot be started in the running state.");
                    case JobState.RunningWithPauseRequest:
                        throw new InvalidOperationException("Job cannot be started in the running with pause request state.");
                    case JobState.Paused:
                        throw new InvalidOperationException("Job cannot be started in the paused state.");
                    case JobState.WaitingToResume:
                        state = JobState.Running;
                        Monitor.Pulse(_lock);
                        break;
                    case JobState.Stopped:
                        throw new InvalidOperationException("Job cannot be started in the stopped state.");
                    case JobState.Finished:
                        throw new InvalidOperationException("Job cannot be started in the finished state.");
                }
            }
        }

        internal void RequestPause()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        // TODO Handle
                        break;
                    case JobState.Running:
                        state = JobState.RunningWithPauseRequest;
                        break;
                    case JobState.RunningWithPauseRequest:
                        break;
                    case JobState.Paused:
                        break;
                    case JobState.WaitingToResume:
                        // TODO Handle
                        break;
                    case JobState.Stopped:
                        throw new InvalidOperationException("Job cannot be paused after being stopped.");
                    case JobState.Finished:
                        throw new InvalidOperationException("Job cannot be paused after finishing.");
                }
            }
        }

        internal void RequestResume()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        throw new InvalidOperationException("Job cannot be resumed before starting.");
                    case JobState.Running:
                        break;
                    case JobState.RunningWithPauseRequest:
                        state = JobState.Running;
                        break;
                    case JobState.Paused:
                        state = JobState.WaitingToResume;
                        OnResumeRequested(this);
                        break;
                    case JobState.WaitingToResume:
                        break;
                    case JobState.Stopped:
                        throw new InvalidOperationException("Job cannot be resumed after being stopped.");
                    case JobState.Finished:
                        throw new InvalidOperationException("Job cannot be resumed after finishing.");
                }
            }
        }

        internal void RequestStop()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        state = JobState.Stopped;
                        break;
                    case JobState.Running:
                        state = JobState.RunningWithStopRequest;
                        break;
                    case JobState.RunningWithPauseRequest:
                        state = JobState.RunningWithStopRequest;
                        break;
                    case JobState.RunningWithStopRequest:
                        break;
                    case JobState.Paused:
                        state = JobState.WaitingToResume;
                        OnResumeRequested(this);
                        break;
                    case JobState.WaitingToResume:
                        // TODO Handle
                        break;
                    case JobState.Stopped:
                        throw new InvalidOperationException("Job cannot be stopped after being stopped.");
                    case JobState.Finished:
                        throw new InvalidOperationException("Job cannot be stopped after finishing.");
                }
            }
        }

        private void Finish()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        throw new InvalidOperationException("Job cannot finish before starting.");
                    case JobState.Running:
                    case JobState.RunningWithPauseRequest:
                    case JobState.RunningWithStopRequest:
                        state = JobState.Finished;
                        OnFinished();
                        break;
                    case JobState.Paused:
                        throw new InvalidOperationException("Job cannot finish while paused.");
                    case JobState.WaitingToResume:
                        throw new InvalidOperationException("Job cannot finish while in waiting state.");
                    case JobState.Stopped:
                        throw new InvalidOperationException("Job cannot finish after being stopped.");
                    case JobState.Finished:
                        return;
                }
            }
        }

        public void CheckForInterrupts()
        {
            lock (_lock)
            {
                switch (state)
                {
                    case JobState.NotStarted:
                        throw new InvalidOperationException("Cannot check for interrupts before starting.");
                    case JobState.Running:
                        break;
                    case JobState.RunningWithPauseRequest:
                        state = JobState.Paused;
                        OnPaused();
                        while (state == JobState.Paused)
                            Monitor.Wait(_lock);
                        break;
                    case JobState.RunningWithStopRequest:
                        state = JobState.Stopped;
                        OnStopped();
                        throw new JobStoppedException();
                    case JobState.Paused:
                        throw new InvalidOperationException("Cannot check for interrupts while paused.");
                    case JobState.WaitingToResume:
                        throw new InvalidOperationException("Cannot check for interrupts while waiting to resume.");
                    case JobState.Stopped:
                        throw new InvalidOperationException("Cannot check for interrupts after job has been stopped.");
                    case JobState.Finished:
                        throw new InvalidOperationException("Cannot check for interrupts after job has finished.");
                }
            }
        }
    }
}
