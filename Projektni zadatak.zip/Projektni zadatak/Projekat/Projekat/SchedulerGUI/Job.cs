﻿using System;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Projekat
{
    public class Job : INotifyPropertyChanged
    {
        private readonly JobExecutionContext jobExecutionContext;

        public Job(JobExecutionContext jobExecutionContext)
        {
            this.jobExecutionContext = jobExecutionContext;
        }

        public JobState State
        {
            get => jobExecutionContext.State;
            private set
            {
                jobExecutionContext.State = value;
                NotifyPropertyChanged();
                NotifyPropertyChanged(nameof(IsStartable));
            }
        }

        private double progress;
        public double Progress
        {
            get
            {
                return progress;
            }

            private set
            {
                progress = value;
                NotifyPropertyChanged();
            }
        }

        private readonly object stateLock = new object();
        public void RequestStart() //NISAM SIGURAN DA LI NAM TREBA BITNO JE SAMO IMATI OVAJ Progress jer je bindovan
        {
            // TODO Cannot start a job that is already running.
            if (!IsStartable)
                return;

            lock (stateLock) // ne treba nam
            {
                State = JobState.Running;
            }

            Task.Run(async () =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Progress = i / 100.0;
                    await Task.Delay(20);
                }

                lock (stateLock)
                {
                    State = JobState.Finished;
                }
            });
        }
        public void RequestPause()
        {
            jobExecutionContext.RequestPause();
        }

        public void RequestResume()
        {
            jobExecutionContext.RequestResume();
        }

        public void RequestStop()
        {
            jobExecutionContext.RequestStop();
        }

        
        [JsonIgnore] // Ovo svojstvo ne treba da se serijalizuje pri JSON serijalizaciji.
        public bool IsStartable //vezati za button start valjda
        {
            get
            {
                lock (stateLock)
                {
                    return State == JobState.NotStarted;
                }
            }
        }

        // TODO Implement
        //[JsonIgnore]
        public bool IsPauseableOrResumable //vezati za button pause resume valjda
        {
            get
            {
                lock (stateLock)
                {
                    return State == JobState.Running;
                }
            }
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
