﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Scheduler scheduler;
        public MainWindow()
        {
            InitializeComponent();
            scheduler = new Scheduler();
            TasksListView.ItemsSource = scheduler.Jobs;

            Dispatcher.InvokeAsync(async () =>
            {
                await Task.Delay(1000);
                scheduler.Jobs.Add(new JobTypeA("Job1"));
                await Task.Delay(1000);
                scheduler.Jobs.Add(new JobTypeA("Job2"));
                await Task.Delay(1000);
                scheduler.Jobs.Add(new JobTypeA("Job3"));
                await Task.Delay(8000);
                scheduler.Jobs.Add(new JobTypeA("Job4"));
            });

        }

        private void txtMaxConcurrentJobs_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtMaxConcurrentJobs.Text == "Enter max concurrent jobs...")
            {
                txtMaxConcurrentJobs.Text = "";
                txtMaxConcurrentJobs.Foreground = Brushes.Black;
            }
        }

        private void txtMaxConcurrentJobs_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaxConcurrentJobs.Text))
            {
                txtMaxConcurrentJobs.Text = "Enter max concurrent jobs...";
                txtMaxConcurrentJobs.Foreground = Brushes.Gray;
            }
        }

        private bool isNumberValid = false;

        private void txtMaxConcurrentJobs_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (int.TryParse(txtMaxConcurrentJobs.Text, out int userInput))
                {
                    scheduler.MaxConJobs = userInput;
                    txtMaxConcurrentJobs.IsReadOnly = true;
                    txtMaxConcurrentJobs.BorderBrush = Brushes.Gray;
                    txtMaxConcurrentJobs.Foreground = Brushes.Gray;
                }
                else
                {
                    txtMaxConcurrentJobs.BorderBrush = Brushes.Red;
                    MessageBox.Show("Invalid input. Please enter a valid number.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                e.Handled = true;
            }

            isNumberValid = true;

            defineJobBtn.IsEnabled = true;
            addJobBtn.IsEnabled = true;
        }

        private DefineJobWindow defineJobWindow;

        private void defineJobBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!isNumberValid) { return; }

            if (defineJobWindow == null || !defineJobWindow.IsVisible)
            {
                defineJobWindow = new DefineJobWindow();
                defineJobWindow.Closed += (s, args) => defineJobWindow = null;
                defineJobWindow.Show();
            }
            else
            {
                defineJobWindow.Activate();
            }
        }

        private AddJobWindow addJobWindow;

        private void addJobBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!isNumberValid) { return; }

            if (addJobWindow == null || !addJobWindow.IsVisible)
            {
                addJobWindow = new AddJobWindow();
                addJobWindow.Closed += (s, args) => addJobWindow = null;
                addJobWindow.Show();
            }
            else
            {
                addJobWindow.Activate();
            }
        }
    }
}
